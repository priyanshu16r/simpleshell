﻿SimpleShell is a basic command-line shell written in C that can execute user commands, handle pipes, run processes in the background, and maintain a command history. It supports both interactive command entry and running scripts from a file.
Features:
1. Command Execution:
   * Executes standard system commands using execvp().
   * Handles basic built-in commands like cd (change directory).
2. Pipes:
   * Supports the execution of multiple commands connected via pipes (e.g., ls | grep txt).
3. Background Processes:
   * Supports running processes in the background by appending & to commands.
4. Command History:
   * Tracks the commands executed, including the process ID, start time, and execution duration.
   * Saves and loads command history to and from a file (Previous_record_tracker.txt).
5. Signal Handling:
   * Handles Ctrl+C signal to display command history before exiting
Limitations:
1. No Built-in Shell Commands (Except cd):
   * Commands like export, alias, unset, and jobs are not supported because these require shell-specific environment handling, which is not implemented.
2. No Advanced Redirection:
   * The shell does not support advanced input/output redirection (>, <, 2>, etc.). Handling file descriptors and redirection would require additional logic not included in this version.
3. No Background Job Management:
   * While background processes (&) are supported, commands like jobs, fg, and bg for managing background processes are not available. There is no process table to track and manage background jobs.
4. Limited Error Handling:
   * The shell does basic error reporting but does not recover or handle complex errors beyond printing error messages.
5. No Aliases or Custom Functions:
   * The shell does not support defining aliases or custom functions for frequently used commands, as seen in more advanced shells.
Contribution: Equal contribution
Github link: https://github.com/priyanshu16r/simpleshell.git