#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_INPUT 1024
#define MAX_ARGS 64

void parse_input(char *input, char **args, int *background) {
    char *token = strtok(input, " \n");
    int i = 0;
    while (token != NULL && i < MAX_ARGS - 1) {
        args[i++] = token;
        token = strtok(NULL, " \n");
    }
    
    // Check for background process
    if (i > 0 && strcmp(args[i-1], "&") == 0) {
        *background = 1;
        args[--i] = NULL;  // Remove &
    } else {
        *background = 0;
    }
    args[i] = NULL;
}

void execute_command(char **args, int background) {
    pid_t pid = fork();

    if (pid == 0) {
        // Child process
        execvp(args[0], args);
        perror("execvp");
        exit(EXIT_FAILURE);
    } else if (pid > 0) {
        // Parent process
        if (!background) {
            waitpid(pid, NULL, 0);
        } else {
            printf("[1] %d\n", pid);
        }
    } else {
        perror("fork");
    }
}

int main() {
    char input[MAX_INPUT];
    char *args[MAX_ARGS];
    int background;

    while (1) {
        printf("MyTerminal> ");
        if (fgets(input, sizeof(input), stdin) == NULL) break;

        parse_input(input, args, &background);

        if (args[0] == NULL) continue;

        if (strcmp(args[0], "exit") == 0) break;

        execute_command(args, background);
    }

    return 0;
}