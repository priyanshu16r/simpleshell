#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <signal.h>

#define MAX_LINE_LENGTH 100
#define HISTORY_FILE_NAME "Previous_record_tracker.txt"

struct CommandStruct{
    char commandArray[MAX_LINE_LENGTH][MAX_LINE_LENGTH];
    pid_t processId;
    struct timeval startTime, endTime;
    long executionDuration;
};

struct CommandStruct commandHistory[MAX_LINE_LENGTH];
int commandCount = 0;

void displayCommandHistory() {
    for (int index = 0; index < commandCount; index++) {
        printf("Command: ");
        for (int j = 0; j < MAX_LINE_LENGTH; j++) {
            printf("%s ", commandHistory[index].commandArray[j]);
        }
        printf("\n");
        printf("Process ID: %d\n", commandHistory[index].processId);
        printf("Start Time: %ld seconds, %d microseconds\n", commandHistory[index].startTime.tv_sec, commandHistory[index].startTime.tv_usec);
        printf("Execution Duration: %ld milliseconds\n", commandHistory[index].executionDuration);
        printf("\n");
    }
}

void addCommandToHistory(char **commandArgs, pid_t processId, struct timeval startTime, long executionDuration) {
    for (int i = 0; commandArgs[i] != NULL; i++) {
        strcpy(commandHistory[commandCount].commandArray[i], commandArgs[i]);
    }
    commandHistory[commandCount].processId = processId;
    commandHistory[commandCount].startTime = startTime;
    commandHistory[commandCount].executionDuration = executionDuration;
    commandCount++;
}

void handleSignal(int signal) {
    printf("\nCtrl+C pressed. Displaying command history:\n");
    displayCommandHistory();
    exit(0);
}

void saveCommandHistoryToFile() {
    FILE *file = fopen(HISTORY_FILE_NAME, "w");
    if (file == NULL) {
        printError("Failed to open command history file");
        return;
    }

    for (int i = 0; i < commandCount; i++) {
        for (int j = 0; j < MAX_LINE_LENGTH; j++) {
            fprintf(file, "%s ", commandHistory[i].commandArray[j]);
        }
        fprintf(file, "\n");
        fprintf(file, "Process ID: %d\n", commandHistory[i].processId);
        fprintf(file, "Start Time: %ld seconds, %d microseconds\n", commandHistory[i].startTime.tv_sec, commandHistory[i].startTime.tv_usec);
        fprintf(file, "Execution Duration: %ld milliseconds\n", commandHistory[i].executionDuration);
        fprintf(file, "\n");
    }

    fclose(file);
}

void loadCommandHistoryFromFile() {
    FILE *file = fopen(HISTORY_FILE_NAME, "r");
    if (file == NULL) {
        printError("Failed to open command history file");
        return;
    }

    char line[MAX_LINE_LENGTH];
    int commandIndex = 0;

    while (fgets(line, sizeof(line), file) != NULL) {
        if (strcmp(line,"\n") == 0){
            continue;

        } else {
            char firstWord[MAX_LINE_LENGTH];
            sscanf(line, "%s", firstWord);

            if (strcmp(firstWord, "Process ID:") == 0) {
                commandIndex = 0;
                commandHistory[commandCount].processId = 0;
                sscanf(line, "Process ID: %d", &commandHistory[commandCount].processId);
            } else if (strcmp(firstWord, "Start") == 0) {
                sscanf(line, "Start Time: %ld seconds, %d microseconds", &commandHistory[commandCount].startTime.tv_sec, &commandHistory[commandCount].startTime.tv_usec);
            } else if (strcmp(firstWord, "Execution Duration:") == 0) {
                sscanf(line, "Execution Duration: %ld milliseconds", &commandHistory[commandCount].executionDuration);
                commandCount++;
            } else{
                char *token;
                token = strtok(line, " \t\n");
                while (token != NULL) {
                    strcpy(commandHistory[commandCount].commandArray[commandIndex++], token);
                    token = strtok(NULL, " \t\n");
                }
            }
        }
    }

    fclose(file);
}

void executeCommand(char **args) {
    pid_t processId;
    int status;
    struct timeval startTime, endTime;

    if (strcmp(args[0], "cd") == 0) {
        if (chdir(args[1]) < 0) {
            printError("chdir");
        }
        gettimeofday(&endTime, NULL);
        gettimeofday(&startTime, NULL);
        long executionDuration = ( endTime.tv_sec - startTime.tv_sec) * 1000 + (endTime.tv_usec- startTime.tv_usec) / 1000;
        addCommandToHistory(args, processId, startTime, executionDuration);
        return;
    }

    if (strcmp(args[0], "history") == 0){
        if (strcmp(args[1], "|") == 0){
            char *args2[MAX_LINE_LENGTH];
            int i;
            for (i = 2; args[i] != NULL; i++) {
                args2[i-2] = args[i];
            }
            args2[i-2] = HISTORY_FILE_NAME;
            args2[i-1] = NULL;
            gettimeofday(&startTime, NULL);
            processId = fork();
            if (processId == 0) {
                execvp(args2[0], args2);
                printError("Execution Error1");
                exit(EXIT_FAILURE);
            } else if (processId < 0) {
                printError("fork process failed");
            } else {
                waitpid(processId, &status, 0);
                gettimeofday(&endTime, NULL);
                long executionDuration = (endTime.tv_sec - startTime.tv_sec) * 1000 + (endTime.tv_usec - startTime.tv_usec) / 1000;
                addCommandToHistory(args, processId, startTime, executionDuration);
            }
        }
        return;
    }
            

    char *originalCommand[MAX_LINE_LENGTH];
    int i;
    for (i = 0; args[i] != NULL; i++) {
        originalCommand[i] = args[i];
    }
    originalCommand[i] = NULL;
    int numPipes = 0;
    for (int i = 0; args[i] != NULL; i++) {
        if (strcmp(args[i], "|") == 0) {
            numPipes++;
        }
    }
    if (numPipes > 0) {
        pid_t id_s[numPipes + 1];
        int arr[numPipes * 2];
        int starter = 0, ender = 0;

        for (int j = 0; j < numPipes; j++) {
            if (pipe(arr + j * 2) == -1) {
                printError("Failed to create pipe");
                exit(EXIT_FAILURE);
            }
        }
        for (int j = 0; j <= numPipes; j++) {
            int ind1 = 0;
            while (args[ender] != NULL && strcmp(args[ender], "|") != 0) {
                ind1++;
                ender++;
            }
            args[ender] = NULL;  
            gettimeofday(&startTime, NULL);
            pid_t id_new = fork();
            if (id_new == 0) {
                if (j < numPipes) {
                    dup2(arr[j * 2 + 1], STDOUT_FILENO);
                }
                if (j > 0) {
                    dup2(arr[(j - 1) * 2], STDIN_FILENO);
                }
                for (int k = 0; k < numPipes * 2; k++) {
                    close(arr[k]);
                }
                execvp(args[starter], args + starter);
                printError("Execution Error");
                exit(EXIT_FAILURE);
            } else if (id_new < 0) {
                printError("fork process failed");
            } else {
                id_s[j] = id_new;
                starter = ++ender;
            }
        }

        for (int j = 0; j < numPipes * 2; j++) {
            close(arr[j]);
        }
        for (int j = 0; j <= numPipes; j++) {
            waitpid(id_s[j], &status, 0);
        }
        gettimeofday(&endTime, NULL);
        long executionDuration = (endTime.tv_sec - startTime.tv_sec) * 1000 + (endTime.tv_usec - startTime.tv_usec) / 1000;
        addCommandToHistory(originalCommand, id_s[numPipes], startTime, executionDuration);
        return;
    }

    gettimeofday(&startTime, NULL);
    processId = fork();
    if (processId == 0) {
        execvp(args[0], args);
        printError("Execution Error");
        exit(EXIT_FAILURE);
    } else if (processId < 0) {
        printError("fork process failed");
    } else {
        waitpid(processId, &status, 0);
        gettimeofday(&endTime, NULL);
        long executionDuration = (endTime.tv_sec - startTime.tv_sec) * 1000 + (endTime .tv_usec - startTime.tv_usec) / 1000;
        addCommandToHistory(originalCommand, processId, startTime, executionDuration);
    }
}

void parseCommand(char *cmd, char **args) {
    char *token;
    int i = 0;

    token = strtok(cmd, " \t\n");
    while (token != NULL) {
        args[i++] = token;
        token = strtok(NULL, " \t\n");
    }
    args[i] = NULL;
}

void printError(char *message) {
    perror(message);
}

void printErrorAndExit(char *message) {
    printError(message);
    exit(EXIT_FAILURE);
}

void printErrorAndReturn(char *message) {
    printError(message);
    return;
}

void changeStackFlow() {
    int a = 10;
    int b = 20;
    int c = a + b;
    return;
}

void changeHeapFlow() {
    int *ptr = (int *)malloc(sizeof(int));
    *ptr = 10;
    free(ptr);
    return;
}

int main(int argc, char *argv[]) {
    char cmd[MAX_LINE_LENGTH];
    char *args[MAX_LINE_LENGTH/2 + 1];
    int shouldRun = 1;

    if (argc > 1) {
        FILE *scriptFile = fopen(argv[1], "r");
        if (scriptFile == NULL) {
            printErrorAndExit("Failed to open script file");
        }

        char line[MAX_LINE_LENGTH];
        while (fgets(line, sizeof(line), scriptFile) != NULL) {
            parseCommand(line, args);
            executeCommand(args);
        }

        fclose(scriptFile);
        return 0;
    }

    signal(SIGINT, handleSignal);

    loadCommandHistoryFromFile();

    do {
        printf("SimpleShell> ");
        fgets(cmd, MAX_LINE_LENGTH, stdin);
        cmd[strlen(cmd) - 1] = '\0'; 

        if (strcmp(cmd, "") == 0) {
            continue; 
        }

        if (strcmp(cmd, "exit") == 0) {
            shouldRun = 0;
            continue;
        }

        if (strcmp(cmd, "history") == 0) {
            for (int i = 0; i < commandCount; i++) {
                printf("%d  ",i+1);
                for (int j = 0; j < MAX_LINE_LENGTH; j++) {
                    printf("%s ", commandHistory[i].commandArray[j]);
                }
                printf("\n");
            }
            continue;
        }

        parseCommand(cmd, args);
        changeStackFlow();
        changeHeapFlow();
        executeCommand(args);
        saveCommandHistoryToFile();
    } while (shouldRun);

    return 0;
}